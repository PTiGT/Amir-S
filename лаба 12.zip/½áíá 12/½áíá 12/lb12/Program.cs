﻿using lb12;
using System.Collections;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Text.RegularExpressions;

IComparer<string> mycomp=Comparer<string>.Create((s1,s2)=>s1.Length-s2.Length);
IComparer<string> mycomp1 = Comparer<string>.Create((s1, s2) => s1.Length - s2.Length);

try
{
    #region z1
    #region test1
    //var stack = new MyStack<string>();
    //string s;
    //var f = new StreamReader(@"..\..\..\laba12.txt");
    //while ((s = f.ReadLine()) != null)
    //{
    //    stack.Push(s);
    //}
    //f.Close();
    //while (!stack.Voidless())
    //{
    //    Console.WriteLine(stack.Pop());
    //}
    //f = new StreamReader(@"..\..\..\laba12.txt");
    //var stck1 = new MyStack<string>();
    //int tp = 0;
    //while ((s = f.ReadLine()) != null)
    //{
    //    stack.Push(s);
    //    if (stck1.Voidless())
    //    {
    //        stck1.Push(s);
    //        tp = 0;
    //    }
    //    else
    //    {
    //        if (stack.Peek().Length < stck1.Peek().Length)
    //        {
    //            stck1.Push(s);
    //            tp += 1;
    //        }
    //        else
    //        {
    //            stck1.Push(stck1.Peek());
    //        }
    //    }
    //}
    //f.Close();
    //Console.WriteLine("мин:" + stck1.Peek() + " номер:" + tp + " длина:" + stck1.Peek().Length);

    ////Задание 1.в
    //var stck2 = new MyStack<string>();
    //int tmp = 0;
    //while (!stack.Voidless())
    //{
    //    if (stck2.Voidless())
    //    {
    //        stck2.Push(stack.Pop());
    //        tp = 0;
    //        tmp = 0;
    //    }
    //    else
    //    {
    //        if (stack.Peek().Length > stck2.Peek().Length)
    //        {
    //            stck2.Push(stack.Pop());

    //        }
    //        else
    //        {
    //            tp = tmp;
    //            stack.Pop();
    //            stck2.Push(stck2.Peek());
    //        }
    //        tmp += 1;
    //    }
    //}
    //Console.WriteLine("max:" + stck2.Peek() + " номер:" + tp + " длина:" + stck2.Peek().Length);
    ////Задание 1.г
    //var nw = new Stack<string>();
    //f = new StreamReader(@"..\..\..\laba12.txt");
    //while ((s = f.ReadLine()) != null)
    //{
    //    nw.Push(s);
    //}
    //f.Close();
    //var nw1 = new Stack<string>();
    //tp = 0;
    //while (nw.Count != 0)
    //{
    //    if (nw1.Count == 0)
    //    {
    //        nw1.Push(nw.Pop());
    //        tp = 0;
    //        tmp = 0;
    //    }
    //    else
    //    {
    //        if (nw.Peek().Length < nw1.Peek().Length)
    //        {
    //            nw1.Push(nw.Pop());
    //            tp++;
    //        }
    //        else
    //        {
    //            nw.Pop();
    //            nw1.Push(nw1.Peek());
    //        }
    //    }
    //}
    //Console.WriteLine("мин:" + nw1.Peek() + " номер:" + tp + " длина:" + nw1.Peek().Length);

    //f = new StreamReader(@"..\..\..\laba12.txt");
    //while ((s = f.ReadLine()) != null)
    //{
    //    nw.Push(s);
    //}
    //f.Close();
    //var nw2 = new Stack<string>();
    //while (nw.Count != 0)
    //{
    //    if (nw2.Count == 0)
    //    {
    //        nw2.Push(nw.Pop());
    //        tp = 0;
    //        tmp = 0;
    //    }
    //    else
    //    {
    //        if (nw.Peek().Length > nw2.Peek().Length)
    //        {
    //            nw2.Push(nw.Pop());

    //        }
    //        else
    //        {
    //            tp = tmp;
    //            nw.Pop();
    //            nw2.Push(nw2.Peek());
    //        }
    //        tmp += 1;
    //    }
    //}
    //Console.WriteLine("max:" + nw2.Peek() + " номер:" + tp + " длина:" + nw2.Peek().Length);
    #endregion
   
   
    
}
catch (Exception e) { Console.WriteLine(e.Message); }
