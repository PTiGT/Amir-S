﻿using System;

namespace lb12
{
    public class MyPair<T1, T2>
    {
        private T1 a;
        private T2 b;

        public MyPair(T1 first, T2 second)
        {
            this.a = first;
            this.b = second;
        }

        virtual public object this[int index]
        {
            get
            {
                if (index == 0)
                {
                    return a;
                }
                else if (index == 1)
                {
                    return b;
                }
                else
                {
                    throw new ArgumentOutOfRangeException("index", "Индекс должен быть либо 0, либо 1..");
                }
            }
            set
            {
                if (index == 0)
                {
                    a = (T1)Convert.ChangeType(value, typeof(T1));
                }
                else if (index == 1)
                {
                    b = (T2)Convert.ChangeType(value, typeof(T2));
                }
                else
                {
                    throw new ArgumentOutOfRangeException("index", "Индекс должен быть либо 0, либо 1.");
                }
            }
        }
    }
} 

